package be.rbgames.smoke;

/** Proof that this library was resolved. */
public final class SmokeTest {
    /** The version this class was built as. */
    public static final String VERSION = "0.0.3";

    private SmokeTest() {
    }
}
